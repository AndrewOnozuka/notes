#ifndef __SHADING_MODE_H__
#define __SHADING_MODE_H__

enum class ShadingMode {
    NORMAL,
    RAY_TRACE,
    DEBUG
};

#endif